###React Starter using babel and webpack

Comes with hot reload feature. Docs to come at some point.

This should resolve some of my headaches when setting up React apps.
I could use CRA, but who wants all of that bloat?
